# Zeta Transporte — projeto demonstrativo

Sistema em PHP 8+, MariaDB/MySQL e Bootstrap 5 com:
- Login e sessão protegida (`login.php`, `dashboard.php`, `logout.php`)
- Catálogo com 6 cards de produtos/serviços
- Página de compra com cálculo demonstrativo de parcelas
- Formulário de envio de currículo
- Script de backup do banco
- SQL para criar banco, tabelas e usuário de demonstração

## Requisitos
PHP 8.1+, MariaDB 10.4+ ou MySQL 8+, extensões `pdo_mysql` e `fileinfo`.
Para executar localmente, use XAMPP, Laragon ou servidor PHP equivalente.

## Instalação
1. Copie a pasta para a raiz pública do servidor (por exemplo `htdocs/zeta_transporte`).
2. Crie o banco executando `database/schema.sql` no phpMyAdmin ou MariaDB.
3. Edite `config/database.php` com host, banco, usuário e senha do seu ambiente.
4. No terminal, dentro da pasta do projeto, execute:
   `php scripts/create_demo_user.php`
   Isso cria o usuário `admin` com senha `Zeta@12345`. Troque a senha depois do primeiro acesso.
5. Acesse `http://localhost/zeta_transporte/`.

## Login demonstrativo
- Usuário: `admin`
- Senha: `Zeta@12345`

## Pagamentos — importante
A tela de compra é demonstrativa e **não cobra pagamentos**. Ela apresenta PIX, cartão (até 6x sem juros) e uma opção ilustrativa de 12 parcelas. A integração real com Mercado Pago, PayPal e Santander exige credenciais de produção/teste, conta de vendedor, configuração de URLs de retorno/webhooks e validação no servidor. Nunca coloque chaves secretas no JavaScript ou no repositório. Configure-as em variáveis de ambiente e siga a documentação oficial de cada provedor. PIX normalmente é pagamento à vista; parcelamento via PIX depende de produto/serviço financeiro oferecido por uma instituição, não é uma função padrão do PIX.

## Currículos e privacidade
Os arquivos são guardados em `storage/curriculos/`, fora da pasta pública se possível. Em produção, configure permissões restritas, política de privacidade, prazo de retenção e acesso apenas por pessoas autorizadas. Não publique currículos no GitHub.

## Backup
Configure `DB_HOST`, `DB_NAME`, `DB_USER` e `DB_PASS` no ambiente e execute:
`bash scripts/backup.sh`
O arquivo SQL será salvo em `backups/`. A pasta de backups está no `.gitignore`; não envie dados pessoais ou backups ao GitHub.

## Envio ao GitHub
Clone o repositório informado, copie os arquivos para a branch exigida pela empresa, faça `git add`, `git commit` e `git push`. Confirme o nome exato da branch com quem solicitou o teste.
