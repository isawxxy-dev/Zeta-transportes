<?php
require __DIR__ . '/../config/database.php';
$username = 'admin';
$password = 'Zeta@12345';
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('INSERT INTO usuarios (username, password) VALUES (?, ?) ON DUPLICATE KEY UPDATE password = VALUES(password)');
$stmt->execute([$username, $hash]);
echo "Usuário demonstrativo criado/atualizado.\nLogin: admin\nSenha: Zeta@12345\nAltere a senha antes de usar em ambiente real.\n";
