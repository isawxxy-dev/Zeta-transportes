#!/usr/bin/env bash
set -euo pipefail
: "${DB_HOST:=127.0.0.1}"
: "${DB_NAME:=zeta_transporte}"
: "${DB_USER:=root}"
: "${DB_PASS:=}"
mkdir -p "$(dirname "$0")/../backups"
STAMP="$(date +%Y%m%d_%H%M%S)"
export MYSQL_PWD="$DB_PASS"
mysqldump --host="$DB_HOST" --user="$DB_USER" --databases "$DB_NAME" > "$(dirname "$0")/../backups/zeta_${STAMP}.sql"
unset MYSQL_PWD
echo "Backup criado em backups/zeta_${STAMP}.sql"
