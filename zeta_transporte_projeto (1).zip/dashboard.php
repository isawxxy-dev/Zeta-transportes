<?php
require_once 'includes/auth.php'; require_login();
$pageTitle='Painel'; require 'includes/header.php';
?>
<main class="container py-5"><div class="card p-4 shadow-sm">
 <h1>Bem-vindo(a), <?= htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8') ?>!</h1>
 <p>Você entrou na área restrita da Zeta Transporte.</p>
 <a class="btn btn-zeta align-self-start" href="logout.php">Sair da conta</a>
</div></main>
<?php require 'includes/footer.php'; ?>
