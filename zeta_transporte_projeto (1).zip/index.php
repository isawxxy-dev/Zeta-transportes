<?php
$pageTitle = 'Início';
require 'includes/header.php';
$products = [
 ['Logística urbana','Entrega e distribuição para operações locais.','https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=700'],
 ['Transporte de cargas','Soluções para movimentação de cargas.','https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=700'],
 ['Armazenagem','Apoio para organização e armazenagem.','https://images.unsplash.com/photo-1586528116493-3c9b5c7f6f3d?w=700'],
 ['Entrega expressa','Serviço prioritário conforme disponibilidade.','https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?w=700'],
 ['Gestão logística','Acompanhamento e planejamento operacional.','https://images.unsplash.com/photo-1553413077-190dd305871c?w=700'],
 ['Distribuição regional','Atendimento regional sob consulta.','https://images.unsplash.com/photo-1519003722824-194d4455a60c?w=700'],
];
$products[1][2]='https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=700';
$products[2][2]='https://images.unsplash.com/photo-1586528116493-3c9b5c7f6f3d?w=700';
$products[3][2]='https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?w=700';
$products[4][2]='https://images.unsplash.com/photo-1553413077-190dd305871c?w=700';
$products[4][2]='https://images.unsplash.com/photo-1553413077-190dd305871c?w=700';
$products[5][2]='https://images.unsplash.com/photo-1519003722824-194d4455a60c?w=700';
$prices = [189.90,349.90,229.90,79.90,499.90,279.90];
?>
<section class="hero"><div class="container">
 <div class="row"><div class="col-lg-8"><p class="text-uppercase fw-bold">Conectando caminhos e negócios</p>
 <h1>Logística inteligente para sua empresa chegar mais longe.</h1>
 <p class="lead">Soluções de transporte, distribuição e apoio logístico.</p>
 <a href="#servicos" class="btn btn-zeta btn-lg mt-2">Conheça os serviços</a></div></div>
</div></section>
<main class="container py-5" id="servicos">
 <div class="text-center mb-4"><h2 class="fw-bold">Nossas <span class="text-zeta">soluções</span></h2><p>Escolha um serviço e consulte as condições.</p></div>
 <div class="row g-4">
 <?php foreach($products as $i=>$p): ?>
 <div class="col-12 col-sm-6 col-lg-4"><div class="card product-card">
  <img src="<?= htmlspecialchars($p[2]) ?>" class="card-img-top" alt="<?= htmlspecialchars($p[0]) ?>">
  <div class="card-body d-flex flex-column"><h5 class="card-title"><?= htmlspecialchars($p[0]) ?></h5>
   <p class="card-text"><?= htmlspecialchars($p[1]) ?></p>
   <p class="fs-5 fw-bold text-zeta mt-auto">R$ <?= number_format($prices[$i],2,',','.') ?></p>
   <a class="btn btn-zeta" href="compra.php?item=<?= $i ?>">Consultar / Comprar</a>
  </div></div></div>
 <?php endforeach; ?>
 </div>
</main>
<?php require 'includes/footer.php'; ?>
