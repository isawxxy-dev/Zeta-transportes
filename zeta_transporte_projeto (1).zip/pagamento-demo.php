<?php
$items=['Logística urbana','Transporte de cargas','Armazenagem','Entrega expressa','Gestão logística','Distribuição regional'];
$id=filter_input(INPUT_POST,'item',FILTER_VALIDATE_INT);
$method=$_POST['metodo']??'';
$allowed=['PIX à vista','Cartão de crédito em até 6x sem juros','12 parcelas (opção ilustrativa)'];
if($id===false || $id===null || !isset($items[$id]) || !in_array($method,$allowed,true)){http_response_code(400);exit('Solicitação inválida.');}
$pageTitle='Pagamento demonstrativo'; require 'includes/header.php';
?>
<main class="container py-5"><div class="panel">
 <div class="alert alert-info">Simulação concluída — nenhuma cobrança foi realizada.</div>
 <h2>Resumo da solicitação</h2><p>Serviço: <strong><?= htmlspecialchars($items[$id]) ?></strong></p>
 <p>Forma selecionada: <strong><?= htmlspecialchars($method) ?></strong></p>
 <p>Para ativar pagamentos, configure o checkout oficial do Mercado Pago, PayPal ou Santander no servidor.</p>
 <a href="index.php" class="btn btn-zeta">Voltar ao início</a>
</div></main>
<?php require 'includes/footer.php'; ?>
