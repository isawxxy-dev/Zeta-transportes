<?php
$pageTitle='Compra';
$items = [
 ['Logística urbana',189.90],['Transporte de cargas',349.90],['Armazenagem',229.90],
 ['Entrega expressa',79.90],['Gestão logística',499.90],['Distribuição regional',279.90]
];
$id = filter_input(INPUT_GET,'item',FILTER_VALIDATE_INT);
if ($id === false || $id === null || !isset($items[$id])) { http_response_code(404); exit('Serviço não encontrado.'); }
[$name,$price] = $items[$id];
require 'includes/header.php';
?>
<main class="container py-5"><div class="panel">
 <h2><?= htmlspecialchars($name) ?></h2><p>Preço demonstrativo: <strong class="text-zeta">R$ <?= number_format($price,2,',','.') ?></strong></p>
 <h5>Condições de pagamento (simulação)</h5>
 <form method="post" action="pagamento-demo.php">
  <input type="hidden" name="item" value="<?= (int)$id ?>">
  <div class="form-check my-2"><input class="form-check-input" type="radio" name="metodo" id="pix" value="PIX à vista" checked><label class="form-check-label" for="pix">PIX à vista</label></div>
  <div class="form-check my-2"><input class="form-check-input" type="radio" name="metodo" id="card" value="Cartão de crédito em até 6x sem juros"><label class="form-check-label" for="card">Cartão de crédito — até 6x sem juros (R$ <?= number_format($price/6,2,',','.') ?> por parcela)</label></div>
  <div class="form-check my-2"><input class="form-check-input" type="radio" name="metodo" id="twelve" value="12 parcelas (opção ilustrativa)"><label class="form-check-label" for="twelve">12 parcelas — opção ilustrativa sujeita à instituição financeira (R$ <?= number_format($price/12,2,',','.') ?> por parcela)</label></div>
  <button class="btn btn-zeta w-100 mt-3">Continuar (simulação)</button>
 </form>
 <p class="small text-muted mt-3">Mercado Pago, PayPal e Santander: integração real ainda requer credenciais e homologação. Nenhuma cobrança é realizada neste projeto.</p>
 <p class="small">O PIX padrão é à vista; parcelamento via PIX depende de serviço financeiro específico.</p>
</div></main>
<?php require 'includes/footer.php'; ?>
