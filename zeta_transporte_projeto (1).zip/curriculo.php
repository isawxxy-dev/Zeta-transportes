<?php
require 'config/database.php';
$message=''; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $nome=trim($_POST['nome']??''); $email=filter_var($_POST['email']??'',FILTER_VALIDATE_EMAIL);
 $telefone=trim($_POST['telefone']??''); $f=$_FILES['curriculo']??null;
 if(!$nome || !$email || !$telefone || !$f || $f['error']!==UPLOAD_ERR_OK){$error='Preencha todos os campos e selecione um arquivo válido.';}
 elseif($f['size']>5*1024*1024){$error='O arquivo deve ter no máximo 5 MB.';}
 else{
  $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
  $exts=['application/pdf'=>'pdf','application/msword'=>'doc','application/vnd.openxmlformats-officedocument.wordprocessingml.document'=>'docx'];
  if(!isset($exts[$mime])){$error='Envie o currículo em PDF, DOC ou DOCX.';}
  else{
   $dir=__DIR__.'/storage/curriculos'; if(!is_dir($dir)) mkdir($dir,0700,true);
   $filename=bin2hex(random_bytes(16)).'.'.$exts[$mime];
   if(move_uploaded_file($f['tmp_name'],$dir.'/'.$filename)){
    $stmt=$pdo->prepare('INSERT INTO curriculos (nome,email,telefone,arquivo) VALUES (?,?,?,?)');
    $stmt->execute([$nome,$email,$telefone,$filename]); $message='Currículo recebido com sucesso.';
   }else{$error='Não foi possível salvar o arquivo.';}
  }
 }
}
$pageTitle='Trabalhe conosco'; require 'includes/header.php';
?>
<main class="container py-5"><div class="panel"><h2>Trabalhe conosco</h2><p>Envie seu currículo para avaliação.</p>
 <?php if($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
 <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
 <form method="post" enctype="multipart/form-data">
  <label class="form-label">Nome completo</label><input class="form-control mb-3" name="nome" maxlength="120" required>
  <label class="form-label">E-mail</label><input class="form-control mb-3" type="email" name="email" maxlength="160" required>
  <label class="form-label">Telefone</label><input class="form-control mb-3" name="telefone" maxlength="30" required>
  <label class="form-label">Currículo (PDF, DOC ou DOCX; até 5 MB)</label><input class="form-control mb-3" type="file" name="curriculo" accept=".pdf,.doc,.docx" required>
  <button class="btn btn-zeta">Enviar currículo</button>
 </form><p class="small text-muted mt-3">Seus dados devem ser tratados conforme a LGPD e acessados apenas por pessoas autorizadas.</p>
</div></main>
<?php require 'includes/footer.php'; ?>
