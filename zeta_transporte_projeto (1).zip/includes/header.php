<?php
$pageTitle = $pageTitle ?? 'Zeta Transporte';
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?> | Zeta Transporte</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark zeta-nav">
 <div class="container">
  <a class="navbar-brand fw-bold" href="index.php">ZETA <span>TRANSPORTE</span></a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu"><span class="navbar-toggler-icon"></span></button>
  <div class="collapse navbar-collapse" id="menu">
   <div class="navbar-nav ms-auto">
    <a class="nav-link" href="index.php">Início</a>
    <a class="nav-link" href="curriculo.php">Trabalhe conosco</a>
    <a class="nav-link" href="login.php">Área do cliente</a>
   </div>
  </div>
 </div>
</nav>
