<footer class="footer mt-5 py-4">
 <div class="container text-center">
  <strong>Zeta Transporte</strong> · Avenida dos Gansos Pretos, 10040 — Nova Esperança, Belém — PA
  <div>Telefone informado: 31 3201-1527 · CNPJ informado: 45.345.496/0001-05</div>
  <small>Projeto demonstrativo. Confirme os dados cadastrais e de contato antes de publicar.</small>
 </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
