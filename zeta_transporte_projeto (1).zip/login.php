<?php
require_once 'includes/auth.php';
require 'config/database.php';
if (!empty($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 $username = trim($_POST['username'] ?? '');
 $password = $_POST['password'] ?? '';
 if ($username === '' || $password === '') {
  $error = 'Preencha usuário e senha.';
 } else {
  $stmt = $pdo->prepare('SELECT id, username, password FROM usuarios WHERE username = ? LIMIT 1');
  $stmt->execute([$username]); $user = $stmt->fetch();
  if ($user && password_verify($password, $user['password'])) {
   session_regenerate_id(true);
   $_SESSION['user_id'] = (int)$user['id'];
   $_SESSION['username'] = $user['username'];
   header('Location: dashboard.php'); exit;
  }
  $error = 'Usuário ou senha inválidos.';
 }
}
$pageTitle='Login'; require 'includes/header.php';
?>
<div class="panel"><h2 class="fw-bold mb-4">Acesso do usuário</h2>
 <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
 <form method="post" action="login.php">
  <div class="mb-3"><label class="form-label" for="username">Usuário</label><input class="form-control" id="username" name="username" required maxlength="80" autocomplete="username"></div>
  <div class="mb-3"><label class="form-label" for="password">Senha</label><input class="form-control" type="password" id="password" name="password" required autocomplete="current-password"></div>
  <button class="btn btn-zeta w-100" type="submit">Entrar</button>
 </form><p class="small text-muted mt-3">Acesso demonstrativo disponível no README.</p>
</div>
<?php require 'includes/footer.php'; ?>
